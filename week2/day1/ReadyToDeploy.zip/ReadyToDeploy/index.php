<!-- Just this one line. Notice how the HTML file is passed as the only argument for the function -->
<?php include_once("HTML-Bio-withCSS.html"); ?>